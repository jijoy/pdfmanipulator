Following is the useage format.

python.exe Main.py
Usage: Main.py rootfolder output-file-path kewords,seperated,by,comma  .
  keywords are optional

Below is an example 

D:\Work\pdfmanipulator\src>D:\Python27\python.exe Main.py D:\Work\data D:\Work\highlighted.pdf MDCT

Where , 

D:\work\data is the root folder , where the documents to be merged is available
D:\work\highlighted.pdf  , is the final output pdf.
MDCT is the keyword , which needs to be highlighted.